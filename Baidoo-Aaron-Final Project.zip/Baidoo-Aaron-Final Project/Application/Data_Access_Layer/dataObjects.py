#Aaron Baidoo
#CSC 6302 / Final Project

# map the tables that you currently have and create each of the tables as a Class
#data classes for Doctors, Staff, Patients and PatientNotes

class Doctors:
    def __init__(self, doctor_id, first_name, last_name, email_address, specialty):
        self.doctor_id = doctor_id
        self.first_name = first_name
        self.last_name = last_name
        self.email_address = email_address
        self.specialty = specialty

class Staff:
    def __init__(self, staff_id, first_name, last_name, email_address, staff_type):
        self.staff_id = staff_id
        self.first_name = first_name
        self.last_name = last_name
        self.email_address = email_address
        self.staff_type = staff_type

class Patients:
    def __init__(self, patient_id, first_name, last_name, email_address, phone_number, date_of_birth, patient_type, doctor_id, staff_id, next_appointment):
        self.patient_id = patient_id
        self.first_name = first_name
        self.last_name = last_name
        self.email_address = email_address
        self.phone_number = phone_number
        self.date_of_birth = date_of_birth
        self.patient_type = patient_type 
        self.doctor_id = doctor_id
        self.staff_id = staff_id
        self.next_appointment = next_appointment

class PatientNotes:
    def __init__(self, note_id, patient_id, note_content, note_date):
        self.note_id = note_id
        self.patient_id = patient_id
        self.note_content = note_content
        self.note_date = note_date        
        