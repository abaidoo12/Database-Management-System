#Aaron Baidoo
#CSC 6302 / Final Project

import mysql.connector

def mydb(role="read_only"):
    """
    Establish and return a connection to the database based on the role.
    """
    if role == "read_only":
        return mysql.connector.connect(
            host="localhost",
            user="read_only",
            password="read1234",
            database="eyeclinic"
        )
    elif role == "write_user":
        return mysql.connector.connect(
            host="localhost",
            user="write_user",
            password="write1234",
            database="eyeclinic"
        )
    else:
        raise ValueError("Invalid role specified. Use 'read_only' or 'write_user'.")
