#Aaron Baidoo
#CSC 6302 / Final Project

import logging  # to collect user logs information / log errors
from Data_Access_Layer.dbConnect import mydb

# Set up logging for error handling
logging.basicConfig(
    level=logging.ERROR,
    filename="app.log",
    filemode="a",
    format="%(asctime)s - %(levelname)s - %(message)s"
)


def add_Notes(patient_email, note_content):
    """Insert a note into the database and return patient details."""
    connection = mydb(role="write_user")  # Connect with write_user
    cursor = connection.cursor(dictionary=True)
    try:
        query = "CALL addNotes(%s, %s)"
        values = (patient_email, note_content)
        cursor.execute(query, values)
        result = cursor.fetchall()
        return result  # Return the fetched patient details
    except Exception as e:
        logging.error(f"Failed to add note. Error: {str(e)} | Query: {query} | Values: {values}")
        return {"error": f"Failed to add note: {str(e)}"}
    finally:
        cursor.close()
        connection.close()


def get_Appointment(patient_email):
    """Retrieve a patient's appointment from the database."""
    connection = mydb(role="read_only")  # Connect with read_only
    cursor = connection.cursor(dictionary=True)
    try:
        query = "CALL getAppointment(%s)"  # Parameterized query for safety
        cursor.execute(query, (patient_email,))  # Pass the email as a tuple
        appointments = cursor.fetchall()
        return appointments
    except Exception as e:
        logging.error(f"Failed to fetch patient appointments. Error: {str(e)} | Query: {query}")
        return {"error": f"Failed to fetch patient appointments: {str(e)}"}
    finally:
        cursor.close()
        connection.close()
