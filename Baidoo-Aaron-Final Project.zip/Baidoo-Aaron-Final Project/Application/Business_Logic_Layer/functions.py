#Aaron Baidoo
#CSC 6302 / Final Project

from Data_Access_Layer.dataMethods import add_Notes, get_Appointment


def handle_get_appointments(patient_email):
    """Fetch and display a patient's appointments."""
    return get_Appointment(patient_email)


def handle_add_patient_note(patient_email, note_content):
    """Add a note for a specific patient and display their details."""
    result = add_Notes(patient_email, note_content)
    if isinstance(result, dict) and "error" in result:
        print(result["error"])
    else:
        print("\nUpdated Patient Information with Notes:")
        for row in result:
            print(f"Patient ID: {row['patient_id']}, Name: {row['first_name']} {row['last_name']}, "
                  f"Email: {row['email_address']}, Next Appointment: {row['next_appointment']}, "
                  f"Note: {row['note_content']}, Note Date: {row['note_date']}")


