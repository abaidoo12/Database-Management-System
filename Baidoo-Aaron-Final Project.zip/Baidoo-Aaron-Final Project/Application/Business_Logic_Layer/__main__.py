#Aaron Baidoo
#CSC 6302 / Final Project

import sys
import os

# Add project root to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from Business_Logic_Layer.functions import handle_get_appointments, handle_add_patient_note

def main():
    try:
        print("Fetching a patient's appointments...")
        patient_email = input("Enter patient email: ")
        appointments = handle_get_appointments(patient_email)
        if isinstance(appointments, dict) and "error" in appointments:
            print(f"Error: {appointments['error']}")
        else:
            for appointment in appointments:
                print(f"Patient: {appointment['first_name']} {appointment['last_name']}, "
                      f"Next Appointment: {appointment['next_appointment']}")

        print("\nAdding a new note for a patient...")
        patient_email = input("Enter patient email: ")
        note_content = input("Enter note content: ")
        handle_add_patient_note(patient_email, note_content)
    except Exception as e:
        print(f"Unexpected error: {str(e)}")

if __name__ == "__main__":
    main()
