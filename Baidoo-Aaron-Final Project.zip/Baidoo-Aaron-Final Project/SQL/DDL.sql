/*
CREATING DATABASE AND TABLES
CREATED BY AARON BAIDOO
CSC 6302 / FINAL PROJECT
*/

-- Create the EyeClinic database
CREATE DATABASE IF NOT EXISTS EyeClinic;

USE EyeClinic;

-- Drop tables if they already exist to avoid errors
DROP TABLE IF EXISTS PatientNotes;
DROP TABLE IF EXISTS Patients;
DROP TABLE IF EXISTS Staffs;
DROP TABLE IF EXISTS Doctors;

-- Create the Doctors table
CREATE TABLE Doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email_address VARCHAR(100) UNIQUE NOT NULL,
    specialty VARCHAR(50) NOT NULL
);

-- Create the Staffs table
CREATE TABLE Staffs (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email_address VARCHAR(100) UNIQUE NOT NULL,
    staff_type VARCHAR(50) NOT NULL
);

-- Create the Patients table
CREATE TABLE Patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email_address VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(15),
    date_of_birth DATE NOT NULL,
    patient_type ENUM('New', 'Established') NOT NULL,
    doctor_id INT,
    staff_id INT,
    next_appointment DATE,
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id),
    FOREIGN KEY (staff_id) REFERENCES Staffs(staff_id)
);

-- Create the PatientNotes table
CREATE TABLE PatientNotes (
    note_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    note_content VARCHAR(500) NOT NULL,
    note_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);
