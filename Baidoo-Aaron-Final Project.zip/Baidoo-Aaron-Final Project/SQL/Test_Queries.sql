-- TEST QUERIES

SELECT * FROM Patients;


-- Add notes for an existing patient
CALL addNotes('alice.johnson@eyepatient.com', 'Patient reported blurry vision.');

-- Attempt to add notes for a non-existent patient
CALL addNotes('nonexistent.email@eyepatient.com', 'This patient does not exist.');

-- Get appointment for an existing patient
CALL getAppointment('alice.johnson@eyepatient.com');

-- Attempt to get appointment for a non-existent patient
CALL getAppointment('nonexistent.email@eyepatient.com');
