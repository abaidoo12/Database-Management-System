/*
INSERTING DATA INTO THE DATABASE
CREATED BY AARON BAIDOO
CSC 6302 / FINAL
*/

-- Insert doctors
INSERT IGNORE INTO Doctors (first_name, last_name, email_address, specialty) VALUES
('John', 'Doe', 'john.doe@eyeclinic.com', 'Ophthalmologist'),
('Jane', 'Smith', 'jane.smith@eyeclinic.com', 'Retina Specialist');

-- Insert staff
INSERT IGNORE INTO Staffs (first_name, last_name, email_address, staff_type) VALUES
('Emily', 'Clark', 'emily.clark@eyeclinic.com', 'Nurse');

-- Insert patients
INSERT IGNORE INTO Patients (first_name, last_name, email_address, phone_number, date_of_birth, patient_type, doctor_id, staff_id, next_appointment) VALUES
('Alice', 'Johnson', 'alice.johnson@eyepatient.com', '1234567890', '1990-01-01', 'New', 1, 1, '2024-12-01');

INSERT IGNORE INTO Patients (
    first_name, last_name, email_address, phone_number, date_of_birth, 
    patient_type, doctor_id, staff_id, next_appointment
) VALUES (
    'Bob', 'Miller', 'bob.miller@eyepatient.com', '9876543210', '1990-03-10', 
    'Established', 2, 2, '2024-12-10'
);

-- Insert notes
INSERT IGNORE INTO PatientNotes (patient_id, note_content) VALUES
(1, 'Initial consultation completed.');
