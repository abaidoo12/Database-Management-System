/*
CREATING PROCEDURE FOR ROLES. 
CREATED BY AARON BAIDOO
CSC- 6302 FINAL PROJECT
*/

DROP PROCEDURE IF EXISTS addNotes;

DELIMITER $$

CREATE PROCEDURE addNotes(
    IN patient_email VARCHAR(100),
    IN note_content VARCHAR(400)
)
BEGIN
    DECLARE patientID INT;

    -- Check if the patient exists
    SELECT patient_id INTO patientID
    FROM Patients
    WHERE email_address = patient_email;

    IF patientID IS NOT NULL THEN
        -- Insert the note into PatientNotes
        INSERT INTO PatientNotes (patient_id, note_content)
        VALUES (patientID, note_content);

        -- Return patient's information and notes
        SELECT 
            p.patient_id,
            p.first_name,
            p.last_name,
            p.email_address,
            p.next_appointment,
            n.note_content,
            n.note_date
        FROM Patients p
        JOIN PatientNotes n ON p.patient_id = n.patient_id
        WHERE p.patient_id = patientID;
    ELSE
        -- Return an error message if the patient does not exist
        SELECT CONCAT('Error: Patient with email "', patient_email, '" does not exist.') AS message;
    END IF;
END$$

DELIMITER ;


DROP PROCEDURE IF EXISTS getAppointment;

DELIMITER $$

CREATE PROCEDURE getAppointment(
    IN patient_email VARCHAR(100)
)
BEGIN
    SELECT 
        patient_id AS Patient_id,
        first_name,
        last_name,
        email_address,
        phone_number,
        date_of_birth,
        patient_type,
        next_appointment
    FROM Patients
    WHERE email_address = patient_email;
END$$

DELIMITER ;
