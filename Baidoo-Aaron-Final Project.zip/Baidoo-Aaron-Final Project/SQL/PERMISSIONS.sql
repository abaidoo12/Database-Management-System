/*
CREATING USER'S PERMISSIONS FOR READ ONLY ROLE, WRITE ONLY ROLE AND ADMIN ROLE. 
CREATED BY AARON BAIDOO
CSC- 6302 FINAL PROJECT
*/

-- Drop roles if they already exist
DROP ROLE IF EXISTS 'admin_role';
DROP ROLE IF EXISTS 'read_role';
DROP ROLE IF EXISTS 'write_role';

-- Creating roles for different levels of access
CREATE ROLE 'admin_role';
CREATE ROLE 'read_role';
CREATE ROLE 'write_role'; -- For users who can INSERT, UPDATE, and DELETE.

-- Granting privileges to roles
GRANT ALL PRIVILEGES ON *.* TO 'admin_role' WITH GRANT OPTION;
GRANT SELECT ON *.* TO 'read_role';
GRANT INSERT, UPDATE, DELETE ON *.* TO 'write_role';

-- Granting EXECUTE privileges to specific procedures and functions
GRANT EXECUTE ON PROCEDURE eyeclinic.getAppointment TO 'read_role';
GRANT EXECUTE ON PROCEDURE eyeclinic.addNotes TO 'write_role';

-- Granting roles to users
GRANT 'admin_role' TO 'admin_user'@'%';
GRANT 'read_role' TO 'read_only'@'%';
GRANT 'write_role' TO 'write_user'@'%';

-- Set default roles for each user
SET DEFAULT ROLE 'admin_role' TO 'admin_user'@'%';
SET DEFAULT ROLE 'read_role' TO 'read_only'@'%';
SET DEFAULT ROLE 'write_role' TO 'write_user'@'%';

-- Explicitly grant EXECUTE privileges to users (optional but ensures clarity)
GRANT EXECUTE ON PROCEDURE eyeclinic.getAppointment TO 'read_only'@'%';
GRANT EXECUTE ON PROCEDURE eyeclinic.addNotes TO 'write_user'@'%';

-- Apply the changes
FLUSH PRIVILEGES;

-- Verify privileges for debugging (optional)
SHOW GRANTS FOR 'read_only'@'%';
SHOW GRANTS FOR 'write_user'@'%';
SHOW GRANTS FOR 'admin_user'@'%';
